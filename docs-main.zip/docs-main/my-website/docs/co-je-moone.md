---
title: Co je Mo.one a Platební identita
description: Představení hlavního produktu Mo.one.
---

# Co je Mo.one

Mo.one je centrální ekosystém...