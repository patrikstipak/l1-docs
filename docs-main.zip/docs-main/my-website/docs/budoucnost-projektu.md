---
title: Budoucnost projektu
description: Vize rozvoje Legi.one.
---

# Budoucnost projektu

Plány expanze, nové funkce a růst sítě Hunterů...

upravím i tohle

a teď jsem opravil i tohlě.
