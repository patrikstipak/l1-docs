---
title: Úvod do Legi.one
description: Základní představení projektu Legi.one.
---

# Úvod

Legi.one je revoluční digitální franšíza...