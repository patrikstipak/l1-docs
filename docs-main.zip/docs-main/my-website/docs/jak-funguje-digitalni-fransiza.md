---
title: Jak funguje digitální franšíza
description: Vysvětlení digitálního modelu Legi.one.
---

# Jak funguje digitální franšíza

Principy, výhody a fungování...