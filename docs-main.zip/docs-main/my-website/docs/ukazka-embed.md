---
title: Ukázka vkládání obsahu
description: Příklad videa, emoji a obrázků.
---

# Ukázka vkládání obsahu

## Video

<iframe width="560" height="315" src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameborder="0" allowfullscreen></iframe>

## Obrázek

![Ukázkový obrázek](../static/img/legi-one-social-card.jpg)

## Emoji

😀 🚀 💼