export default {
  sidebar: [
    'uvod-legione',
    'jak-funguje-digitalni-fransiza',
    'co-je-moone',
    'licencni-modely',
    'jak-vydelava-hunter',
    'sprava-plateb',
    'partneri',
    'budoucnost-projektu',
    'ukazka-embed'
  ],
};