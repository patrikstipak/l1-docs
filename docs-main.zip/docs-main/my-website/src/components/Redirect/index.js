
import React from 'react';
import {Redirect} from '@docusaurus/router';

export default function RedirectComponent() {
  return <Redirect to="/guide/intro" />;
}
